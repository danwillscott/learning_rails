Rails.application.routes.draw do
  get '/', :controller => 'users', :action => 'index'
  get 'new', :controller => 'users', :action => 'add_user'
  get 'show:id', :controller => 'users', :action => 'show'
  post 'new_user', :controller => 'users', :action => 'new_user'
  delete 'delete:id', :controller => 'users', :action => 'delete_user'

  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
end
