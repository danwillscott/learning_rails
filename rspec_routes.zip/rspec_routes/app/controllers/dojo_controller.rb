class DojoController < ApplicationController
  def index
  end

  def world
  end

  def ninjas
  end
end


