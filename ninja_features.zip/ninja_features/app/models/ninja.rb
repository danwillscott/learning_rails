class Ninja < ApplicationRecord
  validates :name, :description, presence: true
end
