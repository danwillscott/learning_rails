module GoldNinjasHelper
end
